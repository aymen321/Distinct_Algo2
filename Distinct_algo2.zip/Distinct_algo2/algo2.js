 function findDistinctElements() {

     const points = new Array(40, 100, 1, 5, 25, 10);
     const points = [40, 100, 1, 5, 25, 10];
     const points2 = new Array(40, 100, 2, 5, 25, 10);
     const points2 = [39, 100, 1, 5, 24, 10];


     for (var i = 0; i < point1.length; i++) {
         var element = point1[i];
         if (map.containsKey(element)) {
             var count = map.get(element);
             map.put(element, count + 1);
         } else
             map.put(element, 1);
     }

     for (var i = 0; i < point2.length; i++) {
         var element = point2[i];
         if (map.containsKey(element)) {
             var count = map.get(element);
             map.put(element, count + 1);
         } else
             map.put(element, 1);
     }


     var sum = 0;
     var set = map.keySet();
     var iterator = set.iterator();
     while (iterator.hasNext()) {
         var key = iterator.next();
         if (map.get(key) == 1)
             sum += key;
     }

     console.log("Distinct Elements Sum : " + sum);
 }